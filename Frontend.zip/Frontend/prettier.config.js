// prettier.config.js or .prettierrc.js
module.exports = {
  plugins: [require("prettier-plugin-tailwindcss")],
};
