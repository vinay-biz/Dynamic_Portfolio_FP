export const tableColumnsTopCreators = [
  {
    Header: "SYMBOL",
    accessor: "symbol",
  },
  {
    Header: "NAME",
    accessor: "name",
  },
  {
    Header: "QUANTITY",
    accessor: "quantity",
  },
  {
    Header: "LINK",
    accessor: "link",
  }
];
